package api.mimascot.v1.api.constantes;

public class Routes {

	public final static String ROUTE_ATENCION ="/v1/atenciones";
}
