package api.mimascot.v1.document.gestion;

public class Especialidad {

}
