package pe.edu.galaxy.training.java.api.reactive.webflux.api.constants;

public class Constants {

	public static final String API_ROUTE_TALLERES="/v1/talleres";
}
