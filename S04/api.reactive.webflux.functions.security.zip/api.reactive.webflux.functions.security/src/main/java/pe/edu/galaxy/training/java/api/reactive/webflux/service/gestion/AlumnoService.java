package pe.edu.galaxy.training.java.api.reactive.webflux.service.gestion;

import pe.edu.galaxy.training.java.api.reactive.webflux.document.gestion.alumnos.Alumno;
import pe.edu.galaxy.training.java.api.reactive.webflux.service.generic.GenericService;

public interface AlumnoService extends GenericService<Alumno>{
	
}