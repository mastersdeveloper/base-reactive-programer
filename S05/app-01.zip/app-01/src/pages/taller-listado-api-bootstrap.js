
import { Component } from "react";
import axios from "axios"
import {Container, Table, Button} from "react-bootstrap"
import 'bootstrap/dist/css/bootstrap.min.css';

export default class TallerListadoApiBootsrap extends Component {
    /*
    npm install axios
    npm install react-bootstrap bootstrap
    */
    constructor(props) {

        super(props);

        this.state = {
            talleres: []
        }
    }
    componentDidMount() {
        this.listar();
    }
    render() {
        return (

            <Container>
                <h1 align="center">Listado de Talleres</h1>
                <Table striped bordered hover>
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Nombre</th>
                            <th>Duración</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.state.talleres.map((taller) => {
                            return (
                                <tr key={taller.id}>
                                    <td align="center">{taller.idTaller}</td>
                                    <td align="center">{taller.nombre}</td>
                                    <td align="center">{taller.duracion}</td>
                                </tr>)
                        })}
                    </tbody>
                </Table>
                <Button variant="danger" style={{ margin: "5px" }}>
                                                    Delete
                                                </Button>
            </Container>
        )
    };

    listar() {
        const url = "http://localhost:8080/talleres";
        axios.get(url)
        .then(response => {
            console.log(response);
            this.setState(
                {
                    //talleres: [{ "id": 1, "nombre": "Producto 1" }]
                    talleres: response.data
                }
    
            )
        })
        .catch(
            error => console.log(error)
        )


        
    }
}