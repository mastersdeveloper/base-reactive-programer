
import { Component } from "react";
import axios from "axios"

export default class TallerListadoApi extends Component {

    constructor(props) {

        super(props);

        this.state = {
            talleres: []
        }
    }
    componentDidMount() {
        this.listar();
    }
    render() {
        return (

            <div>
                <h1 align="center">Listado de Talleres</h1>
                <table width="75%" border="1">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Nombre</th>
                            <th>Duración</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.state.talleres.map((taller) => {
                            return (
                                <tr key={taller.id}>
                                    <td align="center">{taller.idTaller}</td>
                                    <td align="center">{taller.nombre}</td>
                                    <td align="center">{taller.duracion}</td>
                                </tr>)
                        })}
                    </tbody>
                </table>
            </div>
        )
    };

    listar() {
        const url = "http://localhost:8080/talleres";
        axios.get(url)
        .then(response => {
            console.log(response);
            this.setState(
                {
                    //talleres: [{ "id": 1, "nombre": "Producto 1" }]
                    talleres: response.data
                }
    
            )
        })
        .catch(
            error => console.log(error)
        )


        
    }
}