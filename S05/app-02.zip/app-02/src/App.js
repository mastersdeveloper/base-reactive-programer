import logo from './logo.svg';
import './App.css';
import { Container, Navbar, Nav } from "react-bootstrap"
import {BrowserRouter,Switch,Route} from 'react-router-dom'
import 'bootstrap/dist/css/bootstrap.min.css';
import Home from './pages/home'
import TallerListadoApiBootsrap from './pages/taller-listado-api-bootstrap'
import TallerRegistro from './pages/taller-registro';
function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Navbar bg="dark" variant="dark">
          <Container>
          <img src={logo} className="App-logo" alt="logo" />
            <Navbar.Brand href="#home">Home</Navbar.Brand>
            <Nav className="me-auto">
              <Nav.Link href="/taller-listado">Talleres</Nav.Link>
              <Nav.Link href="/alumnos-listado">Alumnos</Nav.Link>
              <Nav.Link href="/instructores-listado">Instructores</Nav.Link>
              <Nav.Link href="/acerca">Acerca</Nav.Link>
            </Nav>
          </Container>
        </Navbar>

        <Switch>
        
        <Route exact path="/" component={Home} />
        <Route path="/taller-listado" component={TallerListadoApiBootsrap} />
        <Route path="/taller-registro" component={TallerRegistro} />
        </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;
