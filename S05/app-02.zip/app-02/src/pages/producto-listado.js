
import { Component } from "react";

export default class ProductoListado extends Component {

    constructor(props) {

        super(props);

        this.state = {
            productos: [],
            id: 0
        }
    }
    componentDidMount() {
        console.log('componentDidMount...')
        this.listar();
        /*
        this.setState(
            {
                productos: [
                    { "id": 1, "nombre": "Producto 1" },
                    { "id": 2, "nombre": "Producto 2" },
                    { "id": 3, "nombre": "Producto 3" }
                ],
                id: 10 
            }
          
        )*/
    }
    render() {
        return (

            <div>
                <h1 align="center">Listado de Productos</h1>
                <table width="75%" border="1">
                    <thead>
                        <tr>
                            <th>Id {this.state.id}</th>
                            <th>Nombre</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.state.productos.map((prod) => {
                            return (
                                <tr key={prod.id}>
                                    <td align="center">{prod.id}</td>
                                    <td align="center">{prod.nombre}</td>
                                </tr>)
                        })}
                    </tbody>
                </table>
            </div>
        )
    };

    listar(){
        this.setState(
            {
                productos: [
                    { "id": 1, "nombre": "Producto 1" },
                    { "id": 2, "nombre": "Producto 2" },
                    { "id": 3, "nombre": "Producto 3" },
                    { "id": 4, "nombre": "Producto 4" }
                ],
                id: 10 
            }
          
        )
    }
}