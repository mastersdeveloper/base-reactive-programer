
import { Component } from "react";
import axios from "axios"
import { Container, Table, Button,Form, Row,Col } from "react-bootstrap"
import { Link } from 'react-router-dom'

export default class TallerListadoApiBootsrap extends Component {
    /*
    npm install axios
    npm install react-bootstrap bootstrap
    */
    constructor(props) {

        super(props);

        this.state = {
            talleres: [],
            taller: {nombre:''}
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleBuscar = this.handleBuscar.bind(this)
    }
    handleChange(event) {

        const target = event.target;

        const value = target.value;
        const name = target.name;

        //console.log('name ->'+ name);
        //console.log('value ->'+ value);

        let taller = { ...this.state.taller };

        taller[name] = value;

        this.setState({ taller });
    }
    componentDidMount() {
        this.handleBuscar();
    }
    render() {
        return (

            <Container>
                <h1 align="center">Listado de Talleres</h1>
                <Form  onSubmit={this.handleBuscar}>
                    <Row>
                        <Col xs={6}>
                            <Form.Group className="mb-2" controlId="nombre">
                                <Form.Label>Nombre</Form.Label>
                                <Form.Control   type="text"
                                                name="nombre"
                                                value={this.state.taller.nombre}
                                                onChange={this.handleChange}   
                                                placeholder="" />
                            </Form.Group>
                        </Col>
                        <Col>
                            <Button variant="primary" type="submit">
                                Buscar
                            </Button>
                        </Col>
                        <Col>   
                            <Link to="/taller-registro">
                                <Button variant="secondary">
                                    Nuevo
                                </Button>
                            </Link>
                        </Col>
                    </Row>
                </Form>
                <Table striped bordered hover>
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Nombre</th>
                            <th>Duración</th>
                             <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.state.talleres.map((taller) => {
                            return (
                                <tr key={taller.id}>
                                    <td align="center">{taller.id} - {taller.idTaller}</td>
                                    <td align="center">{taller.nombre}</td>
                                    <td align="center">{taller.duracion}</td>
                                    <td align="center">
                                    <Link to={`/taller-registro-id/${taller.id}`}>
                                        <Button  variant="success">Modificar</Button>
                                    </Link>
                                    <Link to={`/taller-registro-id/${taller.id}`}>
                                        <Button variant="warning">Eliminar</Button>
                                    </Link>
                                    </td>
                                </tr>)
                        })}
                    </tbody>
                </Table>
               
            </Container>
        )
    };

    handleBuscar(event) {
        if(event){
            event.preventDefault();
        }
        let url = "http://localhost:8080/talleres";
        let nombre = this.state.taller.nombre;
        if(nombre){
            url=`${url}/by-nombre?nombre=${nombre}`
        }
        console.log('url'+url)

        axios.get(url)
            .then(response => {
                console.log(response);
                this.setState(
                    {
                        //talleres: [{ "id": 1, "nombre": "Producto 1" }]
                        talleres: response.data
                    }

                )
            })
            .catch(
                error => console.log(error)
            )



    }
}