import { Component } from "react";
import { Container, Form, Button, Row, Col } from "react-bootstrap"
//import {axios} from 'axios';
import axios from "axios"
export default class TallerRegistrox extends Component {
    taller = {
        id: null,
        idTaller:0,
        nombre: "",
        duracion:0,
        estado: "1"
    }
    constructor(props) {
        super(props);
        console.log('props')
        console.log(this.props)
        //let id=this.props.location.id;
        let id=this.props.match.params.id
        console.log('id ->'+id)
        this.taller.id=id
        this.state = {
            taller: this.taller
        }
       

        this.handleChange= this.handleChange.bind(this);
        this.handleGrabar= this.handleGrabar.bind(this);
        this.handleEliminar= this.handleEliminar.bind(this);
        this.handleCancelar=this.handleCancelar.bind(this);
    }
    
    componentDidMount() {
        let id=this.state.taller.id;
        console.log('id mount ->'+id)
        if(id){
            this.buscarXId(id)
        }
    }
    
    handleGrabar(event) {

        event.preventDefault();
        console.log('handleGrabar')
        const url = "http://localhost:8080/talleres";
        console.log(this.state.taller)
        const { taller } = this.state;
        console.log('Taller')
        console.log(taller)
        let id=this.state.taller.id;
        if(id){
            axios.put(url+'/'+id,taller)
            .then(response => {
                console.log(response);
            })
            .catch(
                error => console.log(error)
            )
        } else {
            axios.post(url,taller)
            .then(response => {
                console.log(response);
            })
            .catch(
                error => console.log(error)
            )
        }
    } 

    handleCancelar(){
        console.log('Cancelar...');
        this.props.history.push("/taller-listado");
    }

    handleEliminar(event){
        console.log('Eliminar...');
        const url = "http://localhost:8080/talleres";
        axios.delete(`${url}/${this.state.taller.id}`)
        .then(response => {
            console.log(response);
            this.handleCancelar();
        })
        .catch(
            error => console.log(error)
        )
    }


    buscarXId(id) {
        const url = "http://localhost:8080/talleres/"+id;
        axios.get(url)
        .then(response => {
            console.log('buscarXId..');
            console.log(response);
            this.setState(
                {
                    taller: response.data
                }
            )
        })
        .catch(
            error => console.log(error)
        )   
    }   

    handleChange(event) {

        const target = event.target;

        const value = target.value;
        const name = target.name;

        //console.log('name ->'+ name);
        //console.log('value ->'+ value);

        let taller = { ...this.state.taller };

        taller[name] = value;

        this.setState({ taller });
    }
    render() {
        return (
            <Container>
                <Form  onSubmit={this.handleGrabar}>
                    <Row>
                        <Col >
                            <Form.Group className="mb-2" controlId="nombre">
                                <Form.Label>Nombre</Form.Label>
                                <Form.Control   type="text"
                                                name="nombre"
                                                value={this.state.taller.nombre}
                                                onChange={this.handleChange}   
                                                placeholder="" />
                            </Form.Group>
                        </Col>
                    </Row>
                    <Row>
                        <Col >
                            <Form.Group className="mb-2" controlId="duracion">
                                <Form.Label>Duracción</Form.Label>
                                <Form.Control   type="text"
                                                name="duracion"
                                                value={this.state.taller.duracion}
                                                onChange={this.handleChange}
                                                placeholder="" />
                            </Form.Group>
                        </Col>
                    </Row>
                    <Row>
                        <Col >
                            <Button variant="primary" type="submit">
                                Grabar
                            </Button>
                        </Col>
                        <Col >
                            <Button variant="warning" onClick={this.handleEliminar}>
                                Eliminar
                            </Button>
                        </Col>
                        <Col >
                            <Button variant="secondary" onClick={this.handleCancelar}>
                                Cancelar
                            </Button>
                        </Col>
                    </Row>
                </Form>
            </Container>
        )
    };
}