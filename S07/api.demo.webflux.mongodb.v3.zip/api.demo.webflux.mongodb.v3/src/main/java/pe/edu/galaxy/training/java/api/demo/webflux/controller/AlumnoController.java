package pe.edu.galaxy.training.java.api.demo.webflux.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import pe.edu.galaxy.training.java.api.demo.webflux.model.Alumno;
import pe.edu.galaxy.training.java.api.demo.webflux.service.AlumnoService;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import static pe.edu.galaxy.training.java.api.demo.webflux.controller.constants.APIConstants.API_AlUMNOS;;

@RestController
@RequestMapping(API_AlUMNOS)
public class AlumnoController {

	@Autowired
	private AlumnoService alumnoService;
	
	@GetMapping
	public Flux<Alumno> getAll() {
		return alumnoService.getAll();
	}
	
	@GetMapping("/by-nombres")
	public Flux<Alumno> findByNombreLike(@RequestParam(name = "nombres",defaultValue = "") String nombre) {
		return alumnoService.findByNombreLike(nombre);
	}
	
	@GetMapping("/{id}")
	public Mono<Alumno> findById(@PathVariable String id) {
		return alumnoService.findById(id);
	}
	
	@GetMapping("/id-alumno/{id}")
	public Mono<Alumno> findById(@PathVariable Integer id) {
		return alumnoService.findByIdAlumno(id);
	}
	
	@PostMapping
	public Mono<Alumno> add(@RequestBody Alumno alumno) {
		return alumnoService.save(alumno);
	}
	
	@PutMapping("/{id}")
	public Mono<Alumno> update(@PathVariable String id, @RequestBody Alumno alumno) {
		alumno.setId(id);
		return alumnoService.save(alumno);
	}
	
	@DeleteMapping("/{id}")
	public Mono<Alumno> delete(@PathVariable String id) {
		return alumnoService.delete(Alumno.builder().id(id).build());
	}
	
}
