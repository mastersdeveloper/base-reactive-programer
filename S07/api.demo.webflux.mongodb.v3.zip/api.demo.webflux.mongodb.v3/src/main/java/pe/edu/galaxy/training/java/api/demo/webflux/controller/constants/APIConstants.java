package pe.edu.galaxy.training.java.api.demo.webflux.controller.constants;

public class APIConstants {

	public static final String API_TALLERES="/v1/talleres";
	public static final String API_AlUMNOS="/v1/alumnos";
}
