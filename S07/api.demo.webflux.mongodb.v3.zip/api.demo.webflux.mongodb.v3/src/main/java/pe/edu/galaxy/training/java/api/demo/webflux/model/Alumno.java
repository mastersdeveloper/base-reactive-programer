package pe.edu.galaxy.training.java.api.demo.webflux.model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Document
public class Alumno {
	
	private String id;
	
	private String idAlumno;
	
	@Field
	private String apellidoPaterno;
	
	@Field
	private String apellidoMaterno;
	
	@Field
	private String nombres;
		
	@Field
	private String estado;
	
}
