package pe.edu.galaxy.training.java.api.demo.webflux.service;

import pe.edu.galaxy.training.java.api.demo.webflux.model.Alumno;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface AlumnoService extends GeneroService<Alumno> {

	Flux<Alumno> findByNombreLike(String nombre); 
	
	Mono<Alumno>  findByIdAlumno(Integer idTaller);
	
}
