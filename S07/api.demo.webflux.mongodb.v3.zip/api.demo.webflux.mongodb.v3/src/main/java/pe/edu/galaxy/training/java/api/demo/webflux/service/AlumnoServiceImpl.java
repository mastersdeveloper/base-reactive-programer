package pe.edu.galaxy.training.java.api.demo.webflux.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;
import pe.edu.galaxy.training.java.api.demo.webflux.model.Alumno;
import pe.edu.galaxy.training.java.api.demo.webflux.respository.AlumnoRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class AlumnoServiceImpl implements AlumnoService {

	@Autowired
	private AlumnoRepository alumnoRepository;

	@Override
	public Flux<Alumno> getAll() {
		return alumnoRepository.findByEstado("1");
	}


	@Override
	public Flux<Alumno> findByNombreLike(String nombre) {
		return alumnoRepository.findByNombresLike(nombre);
	}
	
	
	@Override
	public Mono<Alumno> findById(String id) {
		return alumnoRepository.findById(id);
	}

	@Override
	public Mono<Alumno> findByIdAlumno(Integer idAlumno) {
		return alumnoRepository.findByIdAlumno(idAlumno);
	}

	@Override
	public Mono<Alumno> save(Alumno alumno) {
		return alumnoRepository.save(alumno);
	}

	@Override
	public Mono<Alumno> update(Alumno alumno) {
		return alumnoRepository.findById(alumno.getId()).doOnSuccess(oAlumno -> {
			if (oAlumno != null) {
				oAlumno.setId(alumno.getId());
				oAlumno.setNombres(alumno.getNombres());
				alumnoRepository.save(oAlumno).subscribe();
			}
		});
	}

	@Override
	public Mono<Alumno> delete(Alumno alumno) {
		return alumnoRepository.findById(alumno.getId()).doOnSuccess(oAlumno -> {
			if (oAlumno != null) {
				log.info(".....");
				log.info(oAlumno.toString());
				oAlumno.setEstado("0");
				alumnoRepository.save(oAlumno).subscribe();
			}
		});
		
	}

}
