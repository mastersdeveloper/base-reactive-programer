package pe.edu.galaxy.training.java.api.demo.webflux.service;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface GeneroService<T> {

	Flux<T> getAll();

	Mono<T> findById(String id);

	Mono<T> save(T t);

	Mono<T> update(T t);

	Mono<T> delete(T t);

}