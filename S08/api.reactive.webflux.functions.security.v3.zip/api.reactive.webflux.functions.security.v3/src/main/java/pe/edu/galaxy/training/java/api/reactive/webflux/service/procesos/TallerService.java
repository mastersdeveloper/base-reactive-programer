package pe.edu.galaxy.training.java.api.reactive.webflux.service.procesos;

import pe.edu.galaxy.training.java.api.reactive.webflux.document.procesos.programacion.Taller;
import pe.edu.galaxy.training.java.api.reactive.webflux.service.generic.GenericService;

public interface TallerService extends GenericService<Taller>{
	
}