
class Configuration {
 
    //URL_BASE      =   'http://localhost:8084/siget-backend/';
    URL_BASE        =   'http://localhost:8084/siget-backend-seg/';
    API_TALLERES    =   `${this.URL_BASE}v1/talleres`
    API_ALUMNOS     =   `${this.URL_BASE}v1/alumnos`
}
export default Configuration; 